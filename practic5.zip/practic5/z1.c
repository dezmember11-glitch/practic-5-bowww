#include <stdio.h>
#include <math.h>

int main(void) {
    double A = 0.0, B = 5.0, H = 1.0;
    int n = 1;

    for (double x = A; x <= B; x += H) {
        double y = log(x + 1.0);
        printf("%d  %.4f  %.4f\n", n, x, y);
        n++;
    }

    return 0;
}
