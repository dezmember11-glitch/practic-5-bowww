#include <stdio.h>

#define SIZE 8

int main(void) {
    double arr[SIZE];
    double factorial = 1.0;
    double sum = 0.0;

    for (int i = 0; i < SIZE; i++) {
        factorial *= i + 1;
        arr[i] = factorial;
        sum += arr[i];
    }

    printf("Original: ");

    for (int i = 0; i < SIZE; i++) {
        printf("%.2f ", arr[i]);
    }

    printf("\n");
    printf("Sum: %.2f\n", sum);

    return 0;
}
