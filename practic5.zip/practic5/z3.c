#include <stdio.h>

int main(void) {
    int N;

    printf("Enter N: ");

    while (scanf("%d", &N) == 1 && N > 0) {
        double sum = 0.0;

        for (int i = 1; i <= N; i++) {
            double term = 1.0 / (2 * i - 1);

            if (i % 2 == 0) {
                term = -term;
            }

            sum += term;
        }

        printf("SUM: %.6f\n", sum);
        printf("Enter N: ");
    }

    return 0;
}
