#include <stdio.h>

#define HEIGHT 5

int main(void) {
    for (int i = 1; i <= HEIGHT; i++) {
        for (int j = 1; j <= HEIGHT - i; j++) {
            printf(" ");
        }

        for (int k = 1; k <= i; k++) {
            printf("#");
        }

        printf("\n");
    }

    return 0;
}
