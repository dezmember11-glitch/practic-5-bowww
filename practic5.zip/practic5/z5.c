#include <stdio.h>
#include <math.h>

double calc(double a, double b) {
    return (a * b) / sqrt(a * a + b * b);
}

int main(void) {
    double a, b;

    printf("Enter a and b: ");

    while (scanf("%lf %lf", &a, &b) == 2) {
        if (a == 0 && b == 0) {
            printf("Error: division by zero\n");
        } else {
            double result = calc(a, b);
            printf("RESULT: %.4f\n", result);
        }

        printf("Enter a and b: ");
    }

    return 0;
}
